# ============================================
# Стратегия анализа Mortal Kombat
# ============================================

from datetime import datetime
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from parser import MatchData
from config import (
    TIME_CORRIDORS,
    CHARACTERS_P1,
    CHARACTERS_P2,
    CHARACTER_NAMES,
    MIN_FAT_PROBABILITY,
    MIN_PAIR_FAT,
    MAX_ATV,
    COEF_RANGES
)


@dataclass
class AnalysisResult:
    """Результат анализа матча"""
    should_bet: bool
    confidence: float  # 0-100
    bet_type: str  # "F" (fatality), "B" (brutality), или "none"
    target_rounds: List[int]
    round_range: str  # "1-3", "2-4", "3-5", "4-6"
    fat_coef: float
    brut_coef: float
    fbr_r: float
    atv: float
    time_f_prob: float
    char_f_prob: float
    reason: str
    recommendation: str
    skip_reason: str = ""


class MKStrategy:
    """Стратегия анализа Mortal Kombat на основе полной статистики"""
    
    def __init__(self):
        self.time_corridors = TIME_CORRIDORS
        self.char_p1 = CHARACTERS_P1
        self.char_p2 = CHARACTERS_P2
        self.char_names = CHARACTER_NAMES
    
    def normalize_name(self, name: str) -> str:
        """Нормализует имя персонажа"""
        name_lower = name.lower().replace(' ', '').replace('-', '').replace('_', '').replace('&', '')
        return self.char_names.get(name_lower, name_lower)
    
    def get_character_fat(self, name: str, position: str) -> Dict:
        """Получает фатовость персонажа"""
        normalized = self.normalize_name(name)
        
        if position == "P1":
            return self.char_p1.get(normalized, {"match_f": 50.0, "round1_3": 45.0})
        else:
            return self.char_p2.get(normalized, {"match_f": 50.0, "round1_3": 45.0})
    
    def get_time_corridor(self, match_time: str) -> Tuple[bool, Dict]:
        """Получает данные временного коридора"""
        # Округляем время до ближайших 5 минут
        hour, minute = map(int, match_time.split(':'))
        rounded_minute = (minute // 5) * 5
        corridor_key = f"{hour:02d}:{rounded_minute:02d}"
        
        if corridor_key in self.time_corridors:
            return True, self.time_corridors[corridor_key]
        
        # Проверяем ближайшие коридоры
        for key, data in self.time_corridors.items():
            if abs(self._time_diff(match_time, key)) <= 5:
                return True, data
        
        return False, {"f_prob": 50.0, "b_prob": 50.0, "r_prob": 95.0}
    
    def _time_diff(self, time1: str, time2: str) -> int:
        """Разница в минутах между временами"""
        h1, m1 = map(int, time1.split(':'))
        h2, m2 = map(int, time2.split(':'))
        return abs((h1 * 60 + m1) - (h2 * 60 + m2))
    
    def analyze_characters(self, match: MatchData) -> Tuple[float, str]:
        """Анализирует фатовость персонажей"""
        p1_stats = self.get_character_fat(match.player1, "P1")
        p2_stats = self.get_character_fat(match.player2, "P2")
        
        p1_prob = p1_stats["match_f"]
        p2_prob = p2_stats["match_f"]
        
        # Средняя фатовость пары
        avg_fat = (p1_prob + p2_prob) / 2
        
        # Проверяем, входят ли оба в топ
        p1_in_list = self.normalize_name(match.player1) in self.char_p1
        p2_in_list = self.normalize_name(match.player2) in self.char_p2
        
        if p1_in_list and p2_in_list:
            reason = f"Оба персонажа в списке фатовых (P1:{p1_prob:.1f}%, P2:{p2_prob:.1f}%)"
            score = min(avg_fat * 1.05, 98.0)
        elif p1_in_list or p2_in_list:
            reason = f"Один персонаж фатовый (P1:{p1_prob:.1f}%, P2:{p2_prob:.1f}%)"
            score = avg_fat
        else:
            reason = f"Персонажи не в списке фатовых (P1:{p1_prob:.1f}%, P2:{p2_prob:.1f}%)"
            score = avg_fat * 0.85
        
        return score, reason
    
    def determine_bet_type(self, match: MatchData) -> Tuple[str, float, str]:
        """Определяет тип ставки (F или B)"""
        fat_coef = match.fbr_f
        brut_coef = match.fbr_b
        
        # Чем НИЖЕ коэффициент, тем ВЫШЕ вероятность
        
        # Если F значительно ниже B -> ставим на F
        if fat_coef < brut_coef * 0.85 and fat_coef <= 5.0:
            return "F", 85, f"F={fat_coef} << B={brut_coef}"
        
        # Если B значительно ниже F -> ставим на B
        elif brut_coef < fat_coef * 0.85 and brut_coef <= 5.0:
            return "B", 85, f"B={brut_coef} << F={fat_coef}"
        
        # Если оба низкие -> выбираем минимальный
        elif fat_coef <= 4.5 and brut_coef <= 4.5:
            if fat_coef <= brut_coef:
                return "F", 75, f"Оба низкие, F={fat_coef}"
            else:
                return "B", 75, f"Оба низкие, B={brut_coef}"
        
        # Если F приемлемый
        elif fat_coef <= 5.5:
            return "F", 65, f"F={fat_coef} (приемлемый)"
        
        # Если B приемлемый
        elif brut_coef <= 5.5:
            return "B", 65, f"B={brut_coef} (приемлемый)"
        
        # Оба высокие
        else:
            return "none", 0, f"Оба высокие (F={fat_coef}, B={brut_coef})"
    
    def determine_round_range(self, fat_coef: float, brut_coef: float, bet_type: str) -> Tuple[str, List[int]]:
        """Определяет диапазон раундов для ставки"""
        target_coef = fat_coef if bet_type == "F" else brut_coef
        
        # Коэффициент 2.0-3.0 -> раунды 1-3 (быстрые заходы)
        if 2.0 <= target_coef <= 3.0:
            return "1-3", [1, 2, 3]
        
        # Коэффициент 3.0-3.99 -> раунды 2-4 (средние)
        elif 3.0 < target_coef <= 3.99:
            return "2-4", [2, 3, 4]
        
        # Коэффициент 4.0-4.5 -> раунды 3-5 (поздние)
        elif 4.0 <= target_coef <= 4.5:
            return "3-5", [3, 4, 5]
        
        # Коэффициент > 4.5 -> раунды 4-6 (очень поздние, риск)
        else:
            return "4-6", [4, 5, 6]
    
    def analyze(self, match: MatchData) -> AnalysisResult:
        """Главный метод анализа матча"""
        fat_coef = match.fbr_f
        brut_coef = match.fbr_b
        fbr_r = match.fbr_r
        atv = match.atv
        
        # 1. Проверка временного коридора
        is_elite, corridor_data = self.get_time_corridor(match.match_time)
        time_f_prob = corridor_data.get("f_prob", 50.0)
        
        # 2. Анализ персонажей
        char_f_prob, char_reason = self.analyze_characters(match)
        
        # 3. Проверка ATV (среднее время раунда)
        atv_ok = atv <= MAX_ATV if atv > 0 else True
        
        # 4. Определяем тип ставки
        bet_type, type_score, type_reason = self.determine_bet_type(match)
        
        # 5. Определяем диапазон раундов
        round_range, target_rounds = self.determine_round_range(fat_coef, brut_coef, bet_type)
        
        # 6. Общий confidence score
        # Веса: время 30%, персонажи 40%, тип 30%
        confidence = (time_f_prob * 0.30 + char_f_prob * 0.40 + type_score * 0.30)
        
        # 7. Проверка условий для ставки
        should_bet = True
        skip_reasons = []
        
        # Проверка минимальной вероятности Fatality
        if time_f_prob < MIN_FAT_PROBABILITY:
            should_bet = False
            skip_reasons.append(f"F коридора {time_f_prob:.1f}% < {MIN_FAT_PROBABILITY}%")
        
        # Проверка фатовости пары
        if char_f_prob < MIN_PAIR_FAT:
            should_bet = False
            skip_reasons.append(f"Фатовость пары {char_f_prob:.1f}% < {MIN_PAIR_FAT}%")
        
        # Проверка ATV
        if not atv_ok:
            should_bet = False
            skip_reasons.append(f"ATV {atv} > {MAX_ATV} (риск затяжного матча)")
        
        # Проверка типа ставки
        if bet_type == "none":
            should_bet = False
            skip_reasons.append("Нет подходящего типа ставки")
        
        # 8. Формируем рекомендацию
        if should_bet:
            bet_name = "ФАТАЛИТИ" if bet_type == "F" else "БРУТАЛИТИ"
            recommendation = f"Ставим на {bet_name} (раунды {round_range})"
        else:
            recommendation = "Ставка НЕ рекомендуется"
        
        # 9. Формируем причину
        reason = f"{char_reason}. Время: F={time_f_prob:.1f}%. ATV: {atv}"
        
        skip_reason = "; ".join(skip_reasons) if skip_reasons else ""
        
        return AnalysisResult(
            should_bet=should_bet,
            confidence=confidence,
            bet_type=bet_type,
            target_rounds=target_rounds,
            round_range=round_range,
            fat_coef=fat_coef,
            brut_coef=brut_coef,
            fbr_r=fbr_r,
            atv=atv,
            time_f_prob=time_f_prob,
            char_f_prob=char_f_prob,
            reason=reason,
            recommendation=recommendation,
            skip_reason=skip_reason
        )


class BetTracker:
    """Трекер ставок с отслеживанием по раундам"""
    
    def __init__(self):
        self.active_bets = {}
        self.results = []
    
    def add_bet(self, match_id: str, bet_data: Dict):
        """Добавляет новую ставку"""
        self.active_bets[match_id] = {
            "bet_type": bet_data.get("bet_type"),
            "target_rounds": bet_data.get("target_rounds", []),
            "round_range": bet_data.get("round_range", "1-3"),
            "status": "pending",
            "round_results": [],
            "winning_round": None,
            "result_emoji": None,
            "message_id": None
        }
    
    def set_message_id(self, match_id: str, message_id: int):
        """Устанавливает ID сообщения"""
        if match_id in self.active_bets:
            self.active_bets[match_id]["message_id"] = message_id
    
    def update_round_result(self, match_id: str, round_result) -> Optional[str]:
        """Обновляет результат раунда и проверяет ставку"""
        if match_id not in self.active_bets:
            return None
        
        bet = self.active_bets[match_id]
        
        # Проверяем, не обрабатывали ли мы этот раунд
        if any(r.round_num == round_result.round_num for r in bet["round_results"]):
            return None
        
        bet["round_results"].append(round_result)
        
        bet_type = bet["bet_type"]
        target_rounds = bet["target_rounds"]
        
        # Проверяем, произошло ли НУЖНОЕ добивание
        if round_result.finish_type == bet_type:
            # Если в целевом диапазоне -> ПОБЕДА
            if round_result.round_num in target_rounds:
                bet["status"] = "won"
                bet["winning_round"] = round_result.round_num
                emoji = self._get_result_emoji(round_result.round_num)
                bet["result_emoji"] = emoji
                return emoji
            else:
                # Вне диапазона -> ПРОИГРЫШ
                bet["status"] = "lost"
                bet["winning_round"] = round_result.round_num
                bet["result_emoji"] = "❌"
                return "❌"
        
        # Проверка на окончание диапазона
        max_target_round = max(target_rounds) if target_rounds else 0
        if round_result.round_num >= max_target_round:
            if bet["status"] == "pending":
                bet["status"] = "lost"
                bet["result_emoji"] = "❌"
                return "❌"
        
        return None
    
    def _get_result_emoji(self, round_num: int) -> str:
        """Возвращает количество галочек по номеру раунда"""
        return "✅" * round_num
    
    def get_bet_status(self, match_id: str) -> Dict:
        """Возвращает статус ставки"""
        return self.active_bets.get(match_id, {})
