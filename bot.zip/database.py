# ============================================
# База данных и статистика
# ============================================

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from config import STATS_FILE, ACTIVE_MATCHES_FILE


@dataclass
class DailyStats:
    """Статистика за день"""
    date: str
    total_bets: int = 0
    won_round1: int = 0
    won_round2: int = 0
    won_round3: int = 0
    won_round4: int = 0
    won_round5: int = 0
    won_round6: int = 0
    lost: int = 0
    skipped: int = 0
    
    @property
    def total_won(self) -> int:
        return (self.won_round1 + self.won_round2 + self.won_round3 + 
                self.won_round4 + self.won_round5 + self.won_round6)
    
    @property
    def win_rate(self) -> float:
        completed = self.total_won + self.lost
        if completed == 0:
            return 0.0
        return (self.total_won / completed) * 100
    
    @property
    def profit_emoji(self) -> str:
        if self.win_rate >= 70:
            return "🚀"
        elif self.win_rate >= 55:
            return "📈"
        elif self.win_rate >= 45:
            return "➡️"
        else:
            return "📉"


@dataclass
class MatchRecord:
    """Запись о матче"""
    match_id: str
    match_time: str
    match_date: str
    player1: str
    player2: str
    p1_coef: float
    p2_coef: float
    fat_coef: float
    atv: float
    analysis_confidence: float
    should_bet: bool
    bet_on: Optional[str]
    result: Optional[str] = None
    result_round: Optional[int] = None
    result_emoji: Optional[str] = None
    created_at: str = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()


class StatsManager:
    """Менеджер статистики"""
    
    def __init__(self):
        self.stats_file = STATS_FILE
        self.matches_file = ACTIVE_MATCHES_FILE
        self._ensure_files_exist()
    
    def _ensure_files_exist(self):
        """Создает файлы если не существуют"""
        for file_path in [self.stats_file, self.matches_file]:
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump({}, f, ensure_ascii=False, indent=2)
    
    def _load_json(self, file_path: str) -> Dict:
        """Загружает JSON"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}
    
    def _save_json(self, file_path: str, data: Dict):
        """Сохраняет JSON"""
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def get_daily_stats(self, date: str = None) -> DailyStats:
        """Получает статистику за день"""
        if date is None:
            date = datetime.now().strftime("%d-%m-%Y")
        
        data = self._load_json(self.stats_file)
        stats_data = data.get(date, {})
        
        return DailyStats(
            date=date,
            total_bets=stats_data.get("total_bets", 0),
            won_round1=stats_data.get("won_round1", 0),
            won_round2=stats_data.get("won_round2", 0),
            won_round3=stats_data.get("won_round3", 0),
            won_round4=stats_data.get("won_round4", 0),
            won_round5=stats_data.get("won_round5", 0),
            won_round6=stats_data.get("won_round6", 0),
            lost=stats_data.get("lost", 0),
            skipped=stats_data.get("skipped", 0)
        )
    
    def update_daily_stats(self, stats: DailyStats):
        """Обновляет статистику за день"""
        data = self._load_json(self.stats_file)
        data[stats.date] = {
            "total_bets": stats.total_bets,
            "won_round1": stats.won_round1,
            "won_round2": stats.won_round2,
            "won_round3": stats.won_round3,
            "won_round4": stats.won_round4,
            "won_round5": stats.won_round5,
            "won_round6": stats.won_round6,
            "lost": stats.lost,
            "skipped": stats.skipped
        }
        self._save_json(self.stats_file, data)
    
    def add_match_result(self, match_record: MatchRecord):
        """Добавляет результат матча"""
        date = match_record.match_date
        stats = self.get_daily_stats(date)
        
        stats.total_bets += 1
        
        if match_record.result == "won":
            round_num = match_record.result_round
            if round_num == 1:
                stats.won_round1 += 1
            elif round_num == 2:
                stats.won_round2 += 1
            elif round_num == 3:
                stats.won_round3 += 1
            elif round_num == 4:
                stats.won_round4 += 1
            elif round_num == 5:
                stats.won_round5 += 1
            elif round_num == 6:
                stats.won_round6 += 1
            else:
                stats.lost += 1
        elif match_record.result == "lost":
            stats.lost += 1
        else:
            stats.skipped += 1
        
        self.update_daily_stats(stats)
        
        # Сохраняем запись о матче
        matches = self._load_json(self.matches_file)
        if date not in matches:
            matches[date] = []
        matches[date].append(asdict(match_record))
        self._save_json(self.matches_file, matches)
    
    def get_period_stats(self, days: int = 7) -> Dict:
        """Получает статистику за период"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        total_stats = {
            "total_bets": 0,
            "won_round1": 0,
            "won_round2": 0,
            "won_round3": 0,
            "won_round4": 0,
            "won_round5": 0,
            "won_round6": 0,
            "lost": 0,
            "skipped": 0
        }
        
        data = self._load_json(self.stats_file)
        
        for i in range(days):
            date = (start_date + timedelta(days=i)).strftime("%d-%m-%Y")
            if date in data:
                for key in total_stats:
                    total_stats[key] += data[date].get(key, 0)
        
        total_won = (total_stats["won_round1"] + total_stats["won_round2"] + 
                    total_stats["won_round3"] + total_stats["won_round4"] +
                    total_stats["won_round5"] + total_stats["won_round6"])
        
        total_completed = total_won + total_stats["lost"]
        win_rate = (total_won / total_completed * 100) if total_completed > 0 else 0
        
        return {
            "period_days": days,
            **total_stats,
            "total_won": total_won,
            "win_rate": round(win_rate, 2),
            "profit_emoji": "🚀" if win_rate >= 70 else "📈" if win_rate >= 55 else "➡️" if win_rate >= 45 else "📉"
        }
    
    def format_daily_report(self, date: str = None) -> str:
        """Форматирует ежедневный отчет"""
        if date is None:
            date = datetime.now().strftime("%d-%m-%Y")
        
        stats = self.get_daily_stats(date)
        
        report = (
            f"📊 ЕЖЕДНЕВНЫЙ ОТЧЁТ ({date})\n"
            f"{'=' * 30}\n"
            f"Всего ставок: {stats.total_bets}\n"
            f"{stats.profit_emoji} Побед: {stats.total_won}\n"
            f"  ✅ 1 раунд: {stats.won_round1}\n"
            f"  ✅✅ 2 раунд: {stats.won_round2}\n"
            f"  ✅✅✅ 3 раунд: {stats.won_round3}\n"
            f"  ✅✅✅✅ 4 раунд: {stats.won_round4}\n"
            f"  ✅✅✅✅✅ 5 раунд: {stats.won_round5}\n"
            f"  ✅✅✅✅✅✅ 6 раунд: {stats.won_round6}\n"
            f"❌ Поражений: {stats.lost}\n"
            f"➡️ Пропущено: {stats.skipped}\n"
            f"{'=' * 30}\n"
            f"Win Rate: {stats.win_rate:.1f}%"
        )
        
        return report
    
    def format_period_report(self, days: int = 7) -> str:
        """Форматирует отчет за период"""
        stats = self.get_period_stats(days)
        
        report = (
            f"📊 ОТЧЁТ ЗА {days} ДНЕЙ\n"
            f"{'=' * 30}\n"
            f"Всего ставок: {stats['total_bets']}\n"
            f"{stats['profit_emoji']} Побед: {stats['total_won']}\n"
            f"  ✅ 1 раунд: {stats['won_round1']}\n"
            f"  ✅✅ 2 раунд: {stats['won_round2']}\n"
            f"  ✅✅✅ 3 раунд: {stats['won_round3']}\n"
            f"  ✅✅✅✅ 4 раунд: {stats['won_round4']}\n"
            f"  ✅✅✅✅✅ 5 раунд: {stats['won_round5']}\n"
            f"  ✅✅✅✅✅✅ 6 раунд: {stats['won_round6']}\n"
            f"❌ Поражений: {stats['lost']}\n"
            f"➡️ Пропущено: {stats['skipped']}\n"
            f"{'=' * 30}\n"
            f"Win Rate: {stats['win_rate']}%"
        )
        
        return report
    
    def get_active_matches(self) -> Dict:
        """Получает активные матчи"""
        return self._load_json(self.matches_file)
    
    def save_active_match(self, match_record: MatchRecord):
        """Сохраняет активный матч"""
        matches = self._load_json(self.matches_file)
        date = match_record.match_date
        
        if date not in matches:
            matches[date] = []
        
        existing = [m for m in matches[date] if m["match_id"] == match_record.match_id]
        if not existing:
            matches[date].append(asdict(match_record))
            self._save_json(self.matches_file, matches)
    
    def update_match_result(self, match_id: str, result: str, result_round: int = None, emoji: str = None):
        """Обновляет результат матча"""
        matches = self._load_json(self.matches_file)
        
        for date, match_list in matches.items():
            for match in match_list:
                if match["match_id"] == match_id:
                    match["result"] = result
                    if result_round:
                        match["result_round"] = result_round
                    if emoji:
                        match["result_emoji"] = emoji
                    
                    record = MatchRecord(**match)
                    self.add_match_result(record)
                    
                    self._save_json(self.matches_file, matches)
                    return True
        
        return False
